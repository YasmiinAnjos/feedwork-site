# FeedWork — Carreira & Transparência

Site com banco de dados (SQLite), cadastro/login de usuários e painel de administrador.
Feito só com o que já vem no Node.js: **não precisa rodar `npm install`**.

## Como rodar

1. Instale o **Node.js 22.13 ou mais novo** (https://nodejs.org). Confira com `node -v`.
2. Abra um terminal **dentro desta pasta** e rode:

       node server.js

3. Acesse **http://localhost:3000**

Na primeira execução o banco é criado em `data/feedwork.db`, já com as 5 empresas de exemplo,
e aparece no terminal o administrador inicial:

| E-mail | Senha |
|---|---|
| `admin@feedwork.com` | `admin123` |

**Troque essa senha** logo depois de entrar (menu "Olá, Administrador" → *Alterar senha*).
Para já começar com outro e-mail/senha: `ADMIN_EMAIL=voce@email.com ADMIN_SENHA=outra-senha node server.js`
(só vale na primeira vez, quando ainda não existe administrador).

## O que o sistema faz

- **Usuários:** criar conta, entrar, sair, alterar senha. Senhas guardadas com hash (scrypt); sessão por cookie `httpOnly`.
- **Empresas:** qualquer usuário logado pode cadastrar. Ficam **pendentes** até um administrador aprovar.
- **Avaliações:** só logado avalia (1 por empresa). Ficam **pendentes** até aprovação. Só o apelido aparece; o nome real nunca é exibido.
- **Votos** "útil / não útil" por usuário.
- **Painel admin** (`#/admin`):
  - *Painel*: totais e pendências
  - *Empresas*: aprovar, ocultar, editar, excluir
  - *Avaliações*: aprovar, ocultar, excluir
  - *Usuários*: tornar/remover admin, bloquear/desbloquear, excluir
  - *Contatos B2B*: mensagens enviadas pelo formulário "Para empresas"

## Configurações (variáveis de ambiente)

| Variável | Padrão | Para quê |
|---|---|---|
| `PORT` | `3000` | porta do site |
| `HOST` | `127.0.0.1` | use `0.0.0.0` para hospedar / acessar de outro aparelho |
| `MODERAR_EMPRESAS` | ligado | `0` = empresas novas já saem publicadas |
| `MODERAR_AVALIACOES` | ligado | `0` = avaliações novas já saem publicadas |
| `DB_PATH` | `data/feedwork.db` | local do arquivo do banco |
| `COOKIE_SECURE` | desligado | `1` quando o site estiver em HTTPS |
| `TRUST_PROXY` | desligado | `1` quando o site estiver atrás de túnel/hospedagem (limite de tentativas por visitante) |

Exemplo (Windows PowerShell): `$env:PORT=3001; node server.js`

## Deixar outras pessoas acessarem

**A) Mesma rede Wi-Fi** (sala de aula, casa): rode com `HOST=0.0.0.0`
(PowerShell: `$env:HOST="0.0.0.0"; node server.js`), descubra seu IP com `ipconfig` (linha "Endereço IPv4")
e passe `http://SEU-IP:3000` para as pessoas. Se o Windows perguntar sobre o firewall, permita em "Redes privadas".

**B) Pela internet, enquanto seu PC estiver ligado** (ideal para apresentar): com o site rodando,
use o ngrok (`ngrok http 3000`) ou o Cloudflare Tunnel e passe o link `https://...` que ele mostrar.
Rode o site com `TRUST_PROXY=1`.

**C) Hospedagem de verdade** (Render, Railway, Fly.io...): comando de início `node server.js`, Node 22+,
variáveis `HOST=0.0.0.0`, `TRUST_PROXY=1`, `COOKIE_SECURE=1`, `ADMIN_EMAIL` e `ADMIN_SENHA`.
Atenção: o banco é um arquivo, então a hospedagem precisa de **disco persistente** (volume) e `DB_PATH`
apontando para ele; sem isso os dados somem quando o serviço reinicia.

## Arquivos

    server.js        servidor + API (rotas /api/...)
    db.js            tabelas do banco e dados iniciais
    senha.js         hash de senha
    public/          o site: index.html, style.css, script.js, logo-gatinho.png
    data/            criado sozinho; contém o banco (não envie para o GitHub)

Tabelas: `users`, `sessions`, `companies`, `reviews`, `votes`, `contatos`.

## Dicas

- Para **zerar tudo**: pare o servidor e apague a pasta `data/`.
- Para **ver o banco**: abra `data/feedwork.db` no *DB Browser for SQLite* (gratuito).
- Esqueceu a senha do admin? Apague a pasta `data/` (perde os dados) ou rode com `ADMIN_EMAIL`/`ADMIN_SENHA` num banco novo.
