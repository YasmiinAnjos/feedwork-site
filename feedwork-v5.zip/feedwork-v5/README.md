# FeedWork — Carreira & Transparência

Site com banco de dados (SQLite), cadastro/login de usuários e painel de administrador.
Feito só com o que já vem no Node.js: **não precisa rodar `npm install`**.

## Como rodar

1. Instale o **Node.js 22.13 ou mais novo** (https://nodejs.org). Confira com `node -v`.
2. Abra um terminal **dentro desta pasta** e rode:

       node server.js

3. Acesse **http://localhost:3000**

## Testes

Com Node.js 22.13 ou mais novo, execute `npm test` para rodar os testes automatizados. Não é preciso instalar dependências.

Na primeira execução o banco é criado em `data/feedwork.db`, já com as 5 empresas de exemplo.
Defina as credenciais do administrador inicial no ambiente antes de iniciar. No PowerShell:

  $env:ADMIN_EMAIL='voce@email.com'
  $env:ADMIN_SENHA='uma-senha-com-pelo-menos-12-caracteres'
  node server.js

O administrador só é criado quando ainda não existe uma conta com perfil de administrador. Se o banco já
tem um administrador, essas variáveis não alteram a conta existente; troque a senha pela página "Entrar".

## O que o sistema faz

- **Usuários:** criar conta, entrar, sair, alterar senha, exportar dados em JSON e excluir a própria conta. Cadastro exige aceite versionado dos Termos; consentimento para marketing por e-mail é separado, opcional e revogável. Senhas com mínimo de 12 caracteres, guardadas com hash (scrypt).
- **Cookies:** o cookie essencial `fw_sess` mantém a sessão. O banner permite recusar ou aceitar marketing separadamente; a preferência fica neste navegador. Não há anúncios ou recursos de terceiros ativos.
- **Rate limit:** tentativas são limitadas por endereço IP e guardadas no SQLite, permanecendo após reiniciar o servidor.
- **Empresas:** qualquer usuário logado pode cadastrar. Ficam **pendentes** até um administrador aprovar.
- **Avaliações:** só logado avalia (1 por empresa, mínimo de 20 caracteres no comentário, com contador abaixo do campo).
  Ficam **pendentes** até aprovação. Ao publicar, o autor escolhe **anônima** (padrão) ou **com o seu nome**.
  Depois de publicada, o autor pode **mudar isso** ou **excluir** a avaliação — o texto não pode ser editado.
- **Pesquisa de empresas:** busca por nome + **filtro por categoria** (vem do campo "Setor"; "Fintech / Tecnologia" conta em Fintech e em Tecnologia).
- **Fale conosco** (menu "Contato", ao lado de "Para empresas"): qualquer visitante envia mensagem; o admin lê na aba *Mensagens*.
- **Filtro de palavras:** o admin define as palavras proibidas; textos com elas são recusados no cadastro de conta,
  no cadastro de empresa e nas avaliações (o Fale conosco não é filtrado). Basta cadastrar a palavra **uma vez**:
  o filtro reconhece sozinho maiúsculas, acentos, letras repetidas (`puuuta`), números/símbolos no lugar de letras
  (`p0rra`, `m3rd@`), letras separadas (`p u t a`, `p.u.t.a`), letras escondidas por símbolo (`p*ta`), caracteres
  invisíveis e letras de outros alfabetos parecidas com as nossas. Vale para a palavra inteira ("computador" não é
  barrado por "puta"); para pegar também as derivadas, termine com `*` (ex.: `idiot*`). A lógica fica em `filtro.js`.
- **Votos** "útil / não útil" por usuário.
- **Painel admin** (`#/admin`):
  - *Painel*: totais e pendências
  - *Empresas*: aprovar, ocultar, editar, excluir
  - *Avaliações*: aprovar, ocultar, excluir
  - *Usuários*: tornar/remover admin, bloquear/desbloquear, excluir
  - *Mensagens*: mensagens do "Fale conosco" (responder por e-mail, marcar como lida, excluir)
  - *Contatos B2B*: mensagens enviadas pelo formulário "Para empresas"
  - *Filtro de palavras*: adicionar/remover palavras proibidas (use `*` no fim para bloquear tudo que começa assim, ex.: `idiot*`)

## Configurações (variáveis de ambiente)

| Variável | Padrão | Para quê |
|---|---|---|
| `PORT` | `3000` | porta do site |
| `HOST` | `127.0.0.1` | use `0.0.0.0` para hospedar / acessar de outro aparelho |
| `MODERAR_EMPRESAS` | ligado | `0` = empresas novas já saem publicadas |
| `MODERAR_AVALIACOES` | ligado | `0` = avaliações novas já saem publicadas |
| `DB_PATH` | `data/feedwork.db` | local do arquivo do banco |
| `COOKIE_SECURE` | desligado | `1` quando o site estiver em HTTPS |
| `TRUST_PROXY` | desligado | `1` quando o site estiver atrás de túnel/hospedagem (limite de tentativas por visitante) |
| `SITE_PASSWORD` | não definido | obrigatória no Railway para proteger todo o site e a API; usuário da janela HTTP Basic: `feedwork` |

Exemplo (Windows PowerShell): `$env:PORT=3001; node server.js`

## Deixar outras pessoas acessarem

**A) Mesma rede Wi-Fi** (sala de aula, casa): rode com `HOST=0.0.0.0`
(PowerShell: `$env:HOST="0.0.0.0"; node server.js`), descubra seu IP com `ipconfig` (linha "Endereço IPv4")
e passe `http://SEU-IP:3000` para as pessoas. Se o Windows perguntar sobre o firewall, permita em "Redes privadas".

**B) Pela internet, enquanto seu PC estiver ligado** (ideal para apresentar): com o site rodando,
use o ngrok (`ngrok http 3000`) ou o Cloudflare Tunnel e passe o link `https://...` que ele mostrar.
Rode o site com `TRUST_PROXY=1`.

**C) Hospedagem de verdade** (Render, Railway, Fly.io...): o projeto inclui um `Dockerfile` com Node 22;
na Railway, crie o serviço a partir do repositório e deixe a plataforma detectar esse arquivo.
Adicione um volume montado em `/data` e configure `DB_PATH=/data/feedwork.db`; sem volume, os dados do
SQLite somem quando o serviço reinicia ou é redeployado.

Na Railway, configure também `SITE_PASSWORD`, `ADMIN_EMAIL` e `ADMIN_SENHA` como variáveis do serviço.
`SITE_PASSWORD` protege todas as páginas e rotas da API com uma janela de autenticação; use-a para o
primeiro acesso e depois faça login com a conta de administrador. O Railway define `PORT`; o Dockerfile
já configura `HOST=0.0.0.0`. Se precisar configurar manualmente, use também `TRUST_PROXY=1` e
`COOKIE_SECURE=1` para a hospedagem HTTPS.

## Arquivos

    server.js        servidor + API (rotas /api/...)
    db.js            tabelas do banco e dados iniciais
    senha.js         hash de senha
    filtro.js        filtro de palavras (reconhece disfarces)
    public/          o site: index.html, style.css, script.js, logo-gatinho.png
    data/            criado sozinho; contém o banco (não envie para o GitHub)

Tabelas: `users`, `sessions`, `companies`, `reviews`, `votes`, `contatos`, `mensagens`, `palavras`.

## Dicas

- **Atualizando de uma versão anterior:** copie os arquivos novos por cima e mantenha a pasta `data/`. O banco é atualizado sozinho na primeira execução.

- Para **zerar tudo**: pare o servidor e apague a pasta `data/`.
- Para **ver o banco**: abra `data/feedwork.db` no *DB Browser for SQLite* (gratuito).
- Esqueceu a senha do admin? Apague a pasta `data/` (perde os dados) ou rode com `ADMIN_EMAIL`/`ADMIN_SENHA` num banco novo.

## Visual "Revista" e tema claro/escuro

- O tema (`data-theme` em `<html>`) segue o sistema operacional na primeira visita e a escolha fica em `localStorage` (`fw_tema`). O script `public/tema.js` roda no `<head>` para evitar o "flash".
- As cores ficam nos dois blocos `:root` do topo de `public/style.css`.
- Todo o JavaScript está em arquivos externos (`tema.js`, `script.js`), sem `onclick=` ou `<script>` inline, para funcionar com a CSP `script-src 'self'`.
- Fontes: o design usa **Fraunces** (títulos) e **Familjen Grotesk** (texto). A CSP não permite o Google Fonts, então, sem elas instaladas, entram Georgia e a fonte do sistema. Para usar as originais, baixe os `.woff2`, coloque em `public/fonts/` e adicione `@font-face` no `style.css` (`font-src 'self'` já permite).

## Cadastro de empresa por CNPJ

- Na página "Cadastrar empresa" a pessoa informa o CNPJ (numérico ou alfanumérico, com máscara) e o sistema busca razão social, nome fantasia, sede, atividade e situação cadastral na Receita Federal, via [BrasilAPI](https://brasilapi.com.br). Nome e sede vêm da Receita, não do navegador, e o CPF que aparece no nome de MEIs é removido.
- Antes de cadastrar, o sistema avisa se o CNPJ já existe ou se há empresas de nome parecido. Quem não sabe o CNPJ pode usar o cadastro manual.
- O servidor precisa de saída para a internet. Para trocar a API ou testar sem rede, defina `CNPJ_API_URL`.
- A rota `/api/cnpj/:cnpj` exige login e tem limite de 30 consultas por hora.
- Os testes (`npm test`) usam uma API de CNPJ falsa, sem internet.
- A avaliação agora usa estrelas clicáveis (1 a 5) em cada critério.

## Mais procuradas e salários

- **Mais procuradas:** o servidor soma, por empresa e por dia, quantas pessoas abriram o perfil (uma contagem por IP, empresa e dia; a lista de IPs fica só na memória). O gráfico da home mostra o top 5 dos últimos 7 dias e só aparece com 20+ visitas e 3+ empresas. Endpoint: `GET /api/populares`.
- **Salários:** a faixa mensal é opcional ao avaliar (`faixa_salarial`). A aba "Salários" mostra média estimada (ponto médio das faixas), faixa mais comum e média por cargo, **só com 5 relatos ou mais**. Dados oficiais (IBGE/PNAD, Novo CAGED) não foram incluídos.
