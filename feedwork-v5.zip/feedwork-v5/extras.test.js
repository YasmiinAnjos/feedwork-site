'use strict';
/** Testes de "Mais procuradas" e salários. Rode com: npm test */
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

let app, base, dir;
const H = { 'Content-Type': 'application/json' };
const req = async (m, u, body, cookie, ip) => {
  const r = await fetch(base + u, { method: m, headers: { ...H, ...(cookie ? { Cookie: cookie } : {}), ...(ip ? { 'X-Forwarded-For': ip } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, json: await r.json(), cookie: (r.headers.get('set-cookie') || '').split(';')[0] };
};

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'fw-x-'));
  const porta = 36000 + Math.floor(Math.random() * 2000);
  base = `http://127.0.0.1:${porta}`;
  app = spawn(process.execPath, [path.join(__dirname, 'server.js')], {
    env: { ...process.env, PORT: String(porta), DB_PATH: path.join(dir, 't.db'), TRUST_PROXY: '1', MODERAR_EMPRESAS: '0', MODERAR_AVALIACOES: '0', ADMIN_EMAIL: 'admin@teste.com', ADMIN_SENHA: 'senha-bem-grande-123' },
    stdio: 'ignore',
  });
  for (let i = 0; i < 50; i++) { try { await fetch(base + '/api/categorias'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
});
test.after(() => { app.kill(); fs.rmSync(dir, { recursive: true, force: true }); });

test('salários: média só aparece com 5 relatos; faixa inválida é recusada', async () => {
  const u0 = await req('POST', '/api/auth/registrar', { nome: 'U0', email: 'u0@t.com', senha: 'uma-senha-grande-123', aceitouTermos: true });
  const emp = await req('POST', '/api/empresas', { nome: 'Empresa Teste', setor: 'Tecnologia', sede: 'São Paulo - SP', porte: '1 a 50', desc: '' }, u0.cookie);
  assert.equal(emp.status, 201);
  const id = emp.json.id;
  const av = (c, extra) => req('POST', '/api/avaliacoes', { empresa: id, vinculo: 'atual', cargo: 'Analista', notas: [4, 4, 4, 4], titulo: 'Bom lugar', texto: 'Texto com mais de vinte caracteres.', ...extra }, c);

  assert.equal((await av(u0.cookie, { faixa: 'xx' })).status, 400);
  const faixas = ['f3', 'f3', 'f4', 'f2', null];
  for (let i = 0; i < 5; i++) {
    const u = await req('POST', '/api/auth/registrar', { nome: 'U' + (i + 1), email: `u${i + 1}@t.com`, senha: 'uma-senha-grande-123', aceitouTermos: true });
    assert.equal((await av(u.cookie, { faixa: faixas[i] })).status, 201);
    const d = await req('GET', `/api/empresas/${id}`);
    if (i < 3) assert.equal(d.json.salarios, null, 'com menos de 5 faixas informadas não pode mostrar média');
    if (i == 3) assert.equal(d.json.salarios, null, '4 faixas ainda não bastam');
  }
  // 5ª faixa informada
  const u7 = await req('POST', '/api/auth/registrar', { nome: 'U7', email: 'u7@t.com', senha: 'uma-senha-grande-123', aceitouTermos: true });
  assert.equal((await av(u7.cookie, { faixa: 'f3' })).status, 201);
  const s = (await req('GET', `/api/empresas/${id}`)).json.salarios;
  assert.equal(s.n, 5);
  assert.equal(s.media, 4200);                       // pontos médios: (4000+4000+6500+2500+4000)/5
  assert.equal(s.maisComum.faixa, 'R$ 3.000 a 5.000');
  assert.deepEqual(s.cargos.map((c) => c.cargo), ['Analista']);
});

test('mais procuradas: só aparece com 20 visitas e conta 1 por IP/dia', async () => {
  const lista = (await req('GET', '/api/empresas')).json;
  const id = lista[0].id;
  let p = (await req('GET', '/api/populares')).json;
  const antes = p.total;
  for (let i = 0; i < 3; i++) await req('GET', `/api/empresas/${id}`, null, null, '9.9.9.9');
  p = (await req('GET', '/api/populares')).json;
  assert.equal(p.total, antes + 1, 'recarregar não infla');
  assert.equal(p.ok, false);
  assert.deepEqual(p.itens, []);
});

test('mais procuradas: com 20+ visitas e 3 empresas devolve o ranking ordenado', async () => {
  const u = await req('POST', '/api/auth/registrar', { nome: 'Vera', email: 'v@t.com', senha: 'uma-senha-grande-123', aceitouTermos: true });
  const ids = [];
  for (const n of ['Alfa Ltda', 'Beta Ltda']) ids.push((await req('POST', '/api/empresas', { nome: n, setor: 'Varejo', sede: 'Cotia - SP', porte: '1 a 50', desc: '' }, u.cookie)).json.id);
  const base0 = (await req('GET', '/api/empresas')).json[0].id;
  const visitas = [[base0, 5], [ids[0], 12], [ids[1], 8]];
  for (const [id, n] of visitas) for (let i = 0; i < n; i++) await req('GET', `/api/empresas/${id}`, null, null, `10.0.${id.length}.${i + 1}`);
  const p = (await req('GET', '/api/populares')).json;
  assert.equal(p.ok, true);
  assert.equal(p.itens[0].id, ids[0]);
  assert.ok(p.itens[0].n >= p.itens[1].n && p.itens[1].n >= p.itens[2].n);
});
