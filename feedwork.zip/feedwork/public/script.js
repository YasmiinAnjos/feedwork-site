/* ===== Utilitários ===== */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const toast = m => { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 3200) };
const stars = n => `<span class="star">${'★'.repeat(Math.round(n))}${'☆'.repeat(5 - Math.round(n))}</span>`;
const fmtData = d => d ? new Date(d.replace(' ', 'T') + 'Z').toLocaleDateString('pt-BR') : '';
const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;

/* Chamada à API (sempre JSON, cookie de sessão vai junto) */
async function api(url, { method, body } = {}) {
  const m = method || (body ? 'POST' : 'GET');
  const r = await fetch(url, {
    method: m, credentials: 'same-origin',
    headers: m === 'GET' ? {} : { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : (m === 'GET' ? undefined : '{}')
  });
  let d = {};
  try { d = await r.json() } catch (e) { }
  if (!r.ok) { const err = new Error(d.erro || 'Erro ' + r.status); err.status = r.status; err.data = d; throw err }
  return d;
}

/* ===== Estado ===== */
const CATS = ['Liderança e gestão', 'Plano de carreira', 'Salários e benefícios', 'Ambiente de trabalho'];
let ME = null, Q = '', TAB = 'geral', NEXTTAB = null, FIL = { v: 'todos', o: 'recentes' };
let AUTH = 'login', ADM = 'painel', ADMF = 'todos', RETORNO = null, RT = 0, CAT = '';

const nota = c => c.n ? c.nota.toFixed(1) : '–';
const tile = c => `<div class="tile">${esc(c.nome[0].toUpperCase())}</div>`;
const opts = (cs, sel) => cs.map(c => `<option value="${esc(c.id)}" ${c.id == sel ? 'selected' : ''}>${esc(c.nome)}</option>`).join('');
const badgeEmp = s => s == 'pendente' ? '<span class="badge pend">Em análise</span>' : '';
const precisaLogin = acao => { RETORNO = location.hash; return `<div class="pg"><div class="card form"><h2>Entre para continuar</h2><p class="mut">Você precisa estar logado para ${acao}.</p><br><a class="btn" href="#/entrar">Entrar ou criar conta</a></div></div>` };

/* ===== Páginas públicas ===== */
function coCard(c) {
  return `<a class="card cc" href="#/empresa/${esc(c.id)}"><div class="top">${tile(c)}<div><b>${esc(c.nome)}</b><div class="mut" style="font-size:16px">${esc(c.setor)}</div></div><span class="rate"><span class="star">★</span> ${nota(c)}</span></div>
<span class="tag">✨ ${esc(c.tag)}</span>${badgeEmp(c.status)}<p>${esc(c.desc)}</p><div class="foot"><span>${c.n} avaliações</span><b>Ver detalhes →</b></div></a>`
}
async function home() {
  const cs = (await api('/api/empresas')).filter(c => c.status == 'aprovada');
  const chips = [...cs].sort((a, b) => b.n - a.n).slice(0, 4);
  return `<section class="hero"><span class="pill">A nova era da transparência profissional no Brasil</span>
<h1>Como é de verdade trabalhar e crescer na <span>sua próxima empresa?</span></h1>
<p>Descubra planos de carreira reais, políticas de promoção, salários e relatos honestos de quem já esteve lá dentro.</p>
<form class="sbox" onsubmit="return buscar(event)"><input id="q" placeholder="Digite o nome da empresa (ex: Nubank, TechCorp)"><button class="btn">Pesquisar →</button></form>
<div class="chips">Mais buscadas: ${chips.map(c => `<a href="#/empresa/${esc(c.id)}">${esc(c.nome)}</a>`).join('')}</div></section>
<section class="stats"><div class="in"><div><b>+2.500</b><span>Empresas Avaliadas</span></div><div><b>+45.000</b><span>Ex-funcionários Colaborando</span></div><div><b>98%</b><span>Moderação Rigorosa</span></div><div><b>100%</b><span>Anonimato Garantido</span></div></div></section>
<section class="sec"><div class="eyebrow">DESTAQUES DA COMUNIDADE</div><h2>Empresas com Melhores Planos de Carreira</h2><a class="more" href="#/empresas">Ver todas as empresas →</a>
<div class="grid">${cs.slice(0, 3).map(coCard).join('')}</div></section>
<section class="sec why"><div class="eyebrow">POR QUE O FEEDWORK?</div><h2>Diferente de tudo o que existe no mercado</h2><p class="s">Enquanto outros sites focam apenas em salários genéricos, nós detalhamos a jornada real de crescimento do profissional.</p>
<div class="grid"><div class="card feat"><div class="ic">🪜</div><h3>Foco em Plano de Carreira</h3><p>Saiba com precisão se a empresa promove por mérito ou por antiguidade, qual o ciclo de avaliação e se as promessas de subida de cargo são reais.</p></div>
<div class="card feat"><div class="ic">🛡️</div><h3>Ex-Funcionários Confiáveis</h3><p>Quem já saiu da empresa tem liberdade total para relatar os pontos fortes e fracos sem medo de retaliação corporativa, garantindo total veracidade.</p></div>
<div class="card feat"><div class="ic">💬</div><h3>Transparência Salarial</h3><p>Compare faixas salariais reais por nível (Júnior, Pleno, Sênior, Gerente) e saiba quanto negociar em sua próxima proposta de emprego.</p></div></div></section>`
}
function buscar(e) { e.preventDefault(); Q = $('#q').value.trim(); CAT = ''; location.hash = '#/empresas'; return false }

async function empresas() {
  const [f, cats] = await Promise.all([api('/api/empresas?q=' + encodeURIComponent(Q) + '&categoria=' + encodeURIComponent(CAT)), api('/api/categorias')]);
  const barra = cats.length ? `<div class="catbar"><button class="${CAT ? '' : 'on'}" data-cat="" onclick="setCat(this.dataset.cat)">Todas</button>${cats.map(c => `<button class="${CAT && CAT.toLowerCase() == c.nome.toLowerCase() ? 'on' : ''}" data-cat="${esc(c.nome)}" onclick="setCat(this.dataset.cat)">${esc(c.nome)} (${c.n})</button>`).join('')}</div>` : '';
  const resumo = `<p class="mut" style="margin:14px 0 0">${f.length} empresa(s) encontrada(s)${CAT ? ` em <b>${esc(CAT)}</b>` : ''}${Q ? ` para "<b>${esc(Q)}</b>"` : ''}</p>`;
  return `<div class="pg"><h2>Empresas</h2><form class="sbox" style="margin:0 0 10px;max-width:none" onsubmit="Q=$('#q').value.trim();route();return false"><input id="q" value="${esc(Q)}" placeholder="Pesquise uma empresa..."><button class="btn">Pesquisar →</button></form>
 ${barra}${resumo}
 ${f.length ? `<div class="grid">${f.map(coCard).join('')}</div>` : `<div class="card" style="margin-top:24px">Nenhuma empresa encontrada. ${(CAT || Q) ? '<button class="btn sm o" onclick="limparFiltros()">Limpar filtros</button> ' : ''}<a class="btn sm" href="#/nova-empresa">Cadastrar${Q ? ` "${esc(Q)}"` : ' empresa'}</a></div>`}</div>`
}
function setCat(c) { const q = $('#q'); if (q) Q = q.value.trim(); CAT = c; route(true) }
function limparFiltros() { Q = ''; CAT = ''; route(true) }

async function empresa(id) {
  let d;
  try { d = await api(`/api/empresas/${encodeURIComponent(id)}?v=${FIL.v}&o=${FIL.o}`) } catch (e) { return `<div class="pg">Empresa não encontrada.</div>` }
  const c = d.empresa, rs = d.avaliacoes;
  return `<div class="pg"><a class="more" href="#/empresas">← Voltar para resultados</a>
 <div class="head" style="margin-top:20px">${tile(c)}<div><h1>${esc(c.nome)} ${badgeEmp(c.status)}</h1><div class="mut">${esc(c.setor)}</div><div>${nota(c)} ${stars(c.nota)} <span class="mut">(${c.n} avaliações)</span></div></div>${c.status == 'aprovada' ? `<a class="btn" href="#/avaliar/${esc(c.id)}">Avaliar empresa</a>` : ''}</div>
 <div class="tabs"><button class="${TAB == 'geral' ? 'on' : ''}" onclick="TAB='geral';route(true)">Visão geral</button><button class="${TAB == 'av' ? 'on' : ''}" onclick="TAB='av';route(true)">Avaliações (${c.n})</button></div>
 ${TAB == 'geral' ? `<div class="two"><div class="card"><div class="big">${nota(c)}</div><div style="text-align:center">${stars(c.nota)}<div class="mut">Nota geral</div></div><br>${CATS.map((n, i) => `<div class="bar"><span>${n}</span><i><b style="width:${c.cats[i] * 20}%"></b></i>${c.n ? c.cats[i].toFixed(1) : '–'}</div>`).join('')}</div>
 <div class="card"><h3>Sobre a empresa</h3><p style="margin:10px 0 16px;color:var(--mut)">${esc(c.desc)}</p><p class="mut">Setor: ${esc(c.setor)}<br>Sede: ${esc(c.sede)}<br>Funcionários: ${esc(c.porte)}</p></div></div>`
      : `<div class="layout"><aside class="card"><b>Filtros</b><label>Tipo de avaliação</label><select onchange="FIL.v=this.value;route(true)"><option value="todos">Todos</option><option value="atual" ${FIL.v == 'atual' ? 'selected' : ''}>Funcionários atuais</option><option value="ex" ${FIL.v == 'ex' ? 'selected' : ''}>Ex-funcionários</option></select>
 <label>Ordenar por</label><select onchange="FIL.o=this.value;route(true)"><option value="recentes">Mais recentes</option><option value="likes" ${FIL.o == 'likes' ? 'selected' : ''}>Mais úteis</option></select></aside>
 <div>${rs.length ? rs.map(revCard).join('') : '<div class="card">Ainda não há avaliações. Seja a primeira pessoa a avaliar!</div>'}</div></div>`}</div>`
}
function revCard(r) {
  const emAnalise = r.status == 'pendente';
  const dono = r.minha ? `<div class="dono"><span class="mut">Sua avaliação · aparece como <b>${r.anonima ? 'Anônimo' : esc(r.nome)}</b></span><div class="acts"><button class="btn sm o" onclick="alternarAnon(${r.id},${!r.anonima})">${r.anonima ? 'Mostrar meu nome' : 'Tornar anônima'}</button><button class="btn sm o" onclick="excluirAv(${r.id})">Excluir avaliação</button></div></div>` : '';
  return `<div class="card rev"><span class="badge ${r.vinculo == 'ex' ? 'ex' : ''}">${r.vinculo == 'ex' ? 'Ex-funcionário(a)' : 'Funcionário(a) atual'}</span>${emAnalise ? '<span class="badge pend">Em análise — só você vê</span>' : ''}<span class="mut">${esc(r.nome)} · ${esc(r.cargo)}</span> ${stars(avg(r.notas))}
 <h4>${esc(r.titulo)}</h4><p style="color:var(--mut);white-space:pre-line">${esc(r.texto)}</p>
 ${emAnalise ? '' : `<div class="vote"><button class="${r.meuVoto == 'l' ? 'on' : ''}" onclick="votar(${r.id},'l')">👍 Útil (${r.likes})</button><button class="${r.meuVoto == 'd' ? 'on' : ''}" onclick="votar(${r.id},'d')">👎 Não útil (${r.dislikes})</button></div>`}${dono}</div>`
}
async function alternarAnon(id, anon) {
  try { await api('/api/avaliacoes/' + id, { method: 'PATCH', body: { anonima: anon } }); toast(anon ? 'Sua avaliação agora aparece como Anônimo.' : 'Sua avaliação agora mostra o seu nome.'); route(true) } catch (e) { toast(e.message) }
}
async function excluirAv(id) {
  if (!confirm('Excluir a sua avaliação? Essa ação não pode ser desfeita.')) return;
  try { await api('/api/avaliacoes/' + id, { method: 'DELETE' }); toast('Avaliação excluída.'); route(true) } catch (e) { toast(e.message) }
}
async function votar(id, t) {
  if (!ME) { RETORNO = location.hash; toast('Entre na sua conta para votar.'); location.hash = '#/entrar'; return }
  try { await api(`/api/avaliacoes/${id}/voto`, { body: { tipo: t } }); route(true) } catch (e) { toast(e.message) }
}

async function avaliar(id) {
  if (!ME) return precisaLogin('avaliar uma empresa');
  const cs = (await api('/api/empresas')).filter(c => c.status == 'aprovada');
  return `<div class="pg"><form class="card form" onsubmit="return enviarAv(event)"><h2>Avalie uma empresa</h2><p class="mut">Sua experiência pode ajudar outras pessoas a fazerem escolhas melhores.</p>
 <label>Qual empresa você deseja avaliar?</label><select id="emp" required>${opts(cs, id)}</select><p class="mut" style="margin-top:6px">Não encontrou? <a class="more" href="#/nova-empresa">Cadastre a empresa</a></p>
 <label>Qual é a sua relação com a empresa?</label><select id="vin"><option value="atual">Funcionário(a) atual</option><option value="ex">Ex-funcionário(a)</option></select>
 <div class="row"><div><label>Seu cargo</label><input id="cargo" required maxlength="80" placeholder="Ex.: Analista"></div><div><label>Como sua avaliação aparece</label><select id="anon"><option value="1">Anônima (padrão)</option><option value="0">Com o meu nome (${esc(ME.nome)})</option></select></div></div>
 <label>Dê uma nota (1 a 5)</label><div class="row">${CATS.map(n => `<div><span class="mut">${n}</span><select class="nota">${[5, 4, 3, 2, 1].map(x => `<option>${x}</option>`).join('')}</select></div>`).join('')}</div>
 <label>Título da avaliação</label><input id="tit" required maxlength="80">
 <label>Comentário</label><textarea id="txt" rows="5" required minlength="20" maxlength="3000" oninput="contar(this,20,3000,false)" placeholder="Conte como é trabalhar nessa empresa..."></textarea><div class="hint"><span>Mínimo 20 caracteres</span><span class="cnt">0/3000</span></div><br>
 <button class="btn" style="width:100%">Publicar avaliação</button><div class="note">🔒 Você escolhe como aparecer: anônima ou com o seu nome. Depois de publicada dá para mudar isso, ou excluir a avaliação, mas não dá para editar o texto.</div></form></div>`
}
/* Contador de caracteres logo abaixo do campo (a div .hint tem de vir logo depois do campo) */
function contar(el, min, max, opcional) {
  const h = el.nextElementSibling, t = el.value.trim().length, msg = h.firstElementChild;
  h.querySelector('.cnt').textContent = el.value.length + '/' + max;
  if (opcional && !t) { msg.textContent = 'Opcional. Se preencher, mínimo ' + min + ' caracteres'; h.classList.remove('ok') }
  else if (t >= min) { msg.textContent = 'Mínimo de ' + min + ' caracteres atingido ✓'; h.classList.add('ok') }
  else { msg.textContent = 'Mínimo ' + min + ' caracteres — faltam ' + (min - t); h.classList.remove('ok') }
}
async function enviarAv(e) {
  e.preventDefault(); const id = $('#emp').value;
  try {
    const r = await api('/api/avaliacoes', { body: { empresa: id, vinculo: $('#vin').value, cargo: $('#cargo').value, anonima: $('#anon').value == '1', notas: [...document.querySelectorAll('.nota')].map(s => +s.value), titulo: $('#tit').value, texto: $('#txt').value } });
    toast(r.status == 'pendente' ? 'Avaliação enviada! Ela será publicada após aprovação da moderação.' : 'Avaliação publicada!');
    TAB = 'av'; FIL.v = 'todos'; NEXTTAB = 'av'; location.hash = '#/empresa/' + id
  } catch (err) { toast(err.message) }
  return false
}

async function novaEmpresa() {
  if (!ME) return precisaLogin('cadastrar uma empresa');
  return `<div class="pg"><form class="card form" onsubmit="return enviarEmp(event)"><h2>Cadastrar nova empresa</h2><p class="mut">A empresa que você procura não está na lista? Cadastre-a e seja a primeira pessoa a avaliar.</p>
 <label>Nome da empresa</label><input id="cn" required maxlength="80">
 <div class="row"><div><label>Setor</label><select id="cs"><option>Tecnologia</option><option>Finanças</option><option>Varejo</option><option>Saúde</option><option>Educação</option><option>Indústria</option><option>Serviços</option><option>Outro</option></select></div>
 <div><label>Faixa de funcionários</label><select id="cp"><option>1 a 50</option><option>51 a 200</option><option>201 a 1.000</option><option>1.001 a 5.000</option><option>+5.000</option></select></div></div>
 <label>Sede (cidade - UF)</label><input id="cd" placeholder="São Paulo - SP" required maxlength="80">
 <label>Descrição</label><textarea id="cx" rows="3" minlength="20" maxlength="500" oninput="contar(this,20,500,true)" placeholder="Fale brevemente sobre a empresa"></textarea><div class="hint"><span>Opcional. Se preencher, mínimo 20 caracteres</span><span class="cnt">0/500</span></div><br><button class="btn" style="width:100%">Cadastrar empresa</button></form></div>`
}
async function enviarEmp(e) {
  e.preventDefault();
  try {
    const r = await api('/api/empresas', { body: { nome: $('#cn').value, setor: $('#cs').value, sede: $('#cd').value, porte: $('#cp').value, desc: $('#cx').value } });
    if (r.status == 'pendente') { toast('Empresa enviada! Ela aparecerá para todos após a aprovação da moderação.'); location.hash = '#/empresa/' + r.id }
    else { toast('Empresa cadastrada! Agora avalie-a.'); location.hash = '#/avaliar/' + r.id }
  } catch (err) {
    toast(err.message);
    if (err.status == 409 && err.data && err.data.id) location.hash = '#/empresa/' + err.data.id
  }
  return false
}

function b2b() {
  return `<div class="pg"><div class="eyebrow">FEEDWORK PARA EMPRESAS (B2B)</div><h2>Entenda o que dizem seus funcionários e ex-funcionários</h2><p class="mut" style="font-size:17px">O lado B2C é gratuito. A receita vem de ferramentas e dados para o RH das empresas:</p>
 <div class="grid"><div class="card feat"><div class="ic">📊</div><h3>Painel de Insights e RH Analytics</h3><p>Relatórios e dashboards sobre o que ex-funcionários dizem, gargalos no plano de carreira e talentos perdidos para a concorrência.</p></div>
 <div class="card feat"><div class="ic">🏅</div><h3>Selo de Transparência</h3><p>Empresas bem avaliadas assinam o selo "Empresa Certificada Feedwork" para usar em vagas e atrair melhores profissionais.</p></div>
 <div class="card feat"><div class="ic">📣</div><h3>Resposta e Atração</h3><p>Responda avaliações publicamente, publique vagas direcionadas e destaque sua cultura na plataforma.</p></div></div>
 <h2 style="margin-top:50px">Fale com a gente</h2><form class="card form" style="margin:0" onsubmit="return enviarContato(event)"><label>Empresa</label><input id="bc" required maxlength="100"><label>E-mail corporativo</label><input id="be" type="email" required maxlength="120"><label>Plano de interesse</label><select id="bp"><option>Painel de Insights</option><option>Selo de Transparência</option><option>Resposta e Atração</option></select><br><br><button class="btn">Solicitar demonstração</button></form></div>`
}
async function enviarContato(e) {
  e.preventDefault();
  try { await api('/api/contato', { body: { empresa: $('#bc').value, email: $('#be').value, plano: $('#bp').value } }); toast('Contato enviado! Retornaremos em breve.'); e.target.reset() } catch (err) { toast(err.message) }
  return false
}

/* ===== Fale conosco (usuários) ===== */
function contato() {
  const assuntos = ['Dúvida', 'Sugestão', 'Problema no site', 'Denúncia', 'Elogio', 'Outro'];
  return `<div class="pg"><form class="card form" onsubmit="return enviarMensagem(event)"><h2>Fale conosco</h2><p class="mut">Dúvidas, sugestões ou algum problema? Mande uma mensagem para a equipe do FeedWork.</p>
 <div class="row"><div><label>Seu nome</label><input id="mn" required minlength="2" maxlength="60" value="${esc(ME ? ME.nome : '')}"></div><div><label>Seu e-mail</label><input id="me" type="email" required maxlength="120" value="${esc(ME ? ME.email : '')}"></div></div>
 <label>Assunto</label><select id="ma">${assuntos.map(a => `<option>${a}</option>`).join('')}</select>
 <label>Mensagem</label><textarea id="mm" rows="6" required minlength="10" maxlength="2000" oninput="contar(this,10,2000,false)" placeholder="Escreva sua mensagem..."></textarea><div class="hint"><span>Mínimo 10 caracteres</span><span class="cnt">0/2000</span></div><br>
 <button class="btn" style="width:100%">Enviar mensagem</button><div class="note">Se precisar de resposta, usaremos o e-mail informado acima.</div></form></div>`
}
async function enviarMensagem(e) {
  e.preventDefault();
  try {
    await api('/api/mensagens', { body: { nome: $('#mn').value, email: $('#me').value, assunto: $('#ma').value, mensagem: $('#mm').value } });
    toast('Mensagem enviada! Obrigado pelo contato.'); $('#mm').value = ''; contar($('#mm'), 10, 2000, false)
  } catch (err) { toast(err.message) }
  return false
}

/* ===== Conta: entrar, cadastrar, perfil ===== */
function entrar() {
  if (ME) return `<div class="pg"><div class="card form"><h2>Olá, ${esc(ME.nome)}</h2><p class="mut">${esc(ME.email)} ${ME.role == 'admin' ? '<span class="badge adm">Administrador</span>' : ''}</p><br>
  <div class="acts">${ME.role == 'admin' ? '<a class="btn" href="#/admin">Abrir painel admin</a>' : ''}<button class="btn o" onclick="sair()">Sair</button></div></div>
  <form class="card form" style="margin-top:18px" onsubmit="return trocarSenha(event)"><h3>Alterar senha</h3><label>Senha atual</label><input id="sa" type="password" required autocomplete="current-password"><label>Nova senha (mín. 6 caracteres)</label><input id="sn" type="password" required minlength="6" autocomplete="new-password"><br><br><button class="btn">Salvar nova senha</button></form></div>`;
  const reg = AUTH == 'registro';
  return `<div class="pg"><div class="card form"><div class="tabs" style="margin-top:0"><button class="${reg ? '' : 'on'}" onclick="AUTH='login';route(true)">Entrar</button><button class="${reg ? 'on' : ''}" onclick="AUTH='registro';route(true)">Criar conta</button></div>
  ${reg ? `<form onsubmit="return registrar(event)"><h2>Criar conta</h2><label>Nome</label><input id="rn" required minlength="2" maxlength="60" autocomplete="name"><label>E-mail</label><input id="re" type="email" required autocomplete="email"><label>Senha (mín. 6 caracteres)</label><input id="rs" type="password" required minlength="6" autocomplete="new-password"><br><br><button class="btn" style="width:100%">Criar conta</button></form>`
      : `<form onsubmit="return logar(event)"><h2>Entrar no Feedwork</h2><label>E-mail</label><input id="le" type="email" required autocomplete="email"><label>Senha</label><input id="ls" type="password" required autocomplete="current-password"><br><br><button class="btn" style="width:100%">Entrar</button><div class="note">Ainda não tem conta? Clique em "Criar conta" acima.</div></form>`}
  </div></div>`
}
function depoisDoLogin(user, msg) {
  ME = user; setLogin(); toast(msg);
  const ir = RETORNO && RETORNO != '#/entrar' ? RETORNO : '#/'; RETORNO = null; location.hash = ir
}
async function logar(e) {
  e.preventDefault();
  try { const d = await api('/api/auth/login', { body: { email: $('#le').value, senha: $('#ls').value } }); depoisDoLogin(d.user, 'Bem-vindo(a)!') } catch (err) { toast(err.message) }
  return false
}
async function registrar(e) {
  e.preventDefault();
  try { const d = await api('/api/auth/registrar', { body: { nome: $('#rn').value, email: $('#re').value, senha: $('#rs').value } }); depoisDoLogin(d.user, 'Conta criada! Bem-vindo(a).') } catch (err) { toast(err.message) }
  return false
}
async function trocarSenha(e) {
  e.preventDefault();
  try { await api('/api/auth/senha', { body: { atual: $('#sa').value, nova: $('#sn').value } }); toast('Senha alterada com sucesso.'); e.target.reset() } catch (err) { toast(err.message) }
  return false
}
async function sair() { try { await api('/api/auth/logout', { method: 'POST' }) } catch (e) { } ME = null; setLogin(); AUTH = 'login'; location.hash = '#/'; route() }
const setLogin = () => {
  $('#login').textContent = ME ? 'Olá, ' + ME.nome.split(' ')[0] : 'Entrar';
  $('#adminlink').style.display = ME && ME.role == 'admin' ? '' : 'none'
};

/* ===== Administração ===== */
const ADM_ABAS = [['painel', 'Painel'], ['empresas', 'Empresas'], ['avaliacoes', 'Avaliações'], ['usuarios', 'Usuários'], ['mensagens', 'Mensagens'], ['contatos', 'Contatos B2B'], ['palavras', 'Filtro de palavras']];
const vazio = t => `<div class="card">${t}</div>`;
const tabela = (cab, linhas) => `<div class="tbl-w card" style="padding:8px"><table class="tbl"><thead><tr>${cab.map(c => `<th>${c}</th>`).join('')}</tr></thead><tbody>${linhas.join('')}</tbody></table></div>`;
const bStatus = s => s == 'pendente' ? '<span class="badge pend">Pendente</span>' : '<span class="badge ok">Aprovada</span>';

async function admin() {
  if (!ME || ME.role != 'admin') return `<div class="pg"><div class="card form"><h2>Acesso restrito</h2><p class="mut">Esta área é exclusiva para administradores.</p><br><a class="btn" href="#/entrar">Entrar</a></div></div>`;
  const s = await api('/api/admin/stats');
  const corpo = await ({ painel: () => admPainel(s), empresas: admEmpresas, avaliacoes: admAvaliacoes, usuarios: admUsuarios, mensagens: admMensagens, contatos: admContatos, palavras: admPalavras }[ADM] || (() => admPainel(s)))();
  return `<div class="pg"><div class="eyebrow">ADMINISTRAÇÃO</div><h2>Painel do administrador</h2>
  <div class="tabs">${ADM_ABAS.map(([k, n]) => `<button class="${ADM == k ? 'on' : ''}" onclick="ADM='${k}';route(true)">${n}${k == 'mensagens' && s.mensagensNovas ? ` <span class="badge pend">${s.mensagensNovas}</span>` : ''}</button>`).join('')}</div>${corpo}</div>`
}
async function admPainel(s) {
  const k = (n, t, aba, alerta) => `<a class="card kpi ${alerta && n ? 'alerta' : ''}" href="#/admin" onclick="ADM='${aba}';route(true);return false"><b>${n}</b><span>${t}</span></a>`;
  return `<div class="kpis">${k(s.usuarios, 'Usuários cadastrados', 'usuarios')}${k(s.empresasAprovadas, 'Empresas publicadas', 'empresas')}${k(s.empresasPendentes, 'Empresas aguardando aprovação', 'empresas', 1)}
  ${k(s.avaliacoesAprovadas, 'Avaliações publicadas', 'avaliacoes')}${k(s.avaliacoesPendentes, 'Avaliações aguardando aprovação', 'avaliacoes', 1)}${k(s.mensagensNovas, 'Mensagens novas (Fale conosco)', 'mensagens', 1)}
  ${k(s.contatos, 'Contatos B2B recebidos', 'contatos')}${k(s.palavras, 'Palavras no filtro', 'palavras')}</div>
  <p class="mut" style="margin-top:18px">Administradores: ${s.admins} · Contas bloqueadas: ${s.bloqueados}</p>`
}
async function adm(url, method, body, msg, confirma) {
  if (confirma && !confirm(confirma)) return;
  try { await api(url, { method, body }); toast(msg); route(true) } catch (e) { toast(e.message) }
}
async function admEmpresas() {
  const cs = await api('/api/admin/empresas');
  if (!cs.length) return vazio('Nenhuma empresa cadastrada.');
  return tabela(['Empresa', 'Setor / Sede', 'Status', 'Avaliações', 'Cadastrada por', 'Ações'], cs.map(c => `<tr><td><a class="more" href="#/empresa/${esc(c.id)}">${esc(c.nome)}</a><div class="mut">${fmtData(c.criado_em)}</div></td><td>${esc(c.setor)}<div class="mut">${esc(c.sede)}</div></td><td>${bStatus(c.status)}</td><td>${c.avaliacoes}</td><td>${c.criador_email ? esc(c.criador_nome) + '<div class="mut">' + esc(c.criador_email) + '</div>' : '<span class="mut">Dados iniciais</span>'}</td>
  <td><div class="acts">${c.status == 'pendente' ? `<button class="btn sm" onclick="adm('/api/admin/empresas/${esc(c.id)}','PATCH',{status:'aprovada'},'Empresa aprovada.')">Aprovar</button>` : `<button class="btn sm o" onclick="adm('/api/admin/empresas/${esc(c.id)}','PATCH',{status:'pendente'},'Empresa ocultada (voltou para análise).')">Ocultar</button>`}
  <a class="btn sm o" href="#/admin-empresa/${esc(c.id)}">Editar</a><button class="btn sm o" onclick="adm('/api/admin/empresas/${esc(c.id)}','DELETE',null,'Empresa excluída.','Excluir esta empresa e todas as avaliações dela? Isso não pode ser desfeito.')">Excluir</button></div></td></tr>`))
}
async function admEditar(id) {
  if (!ME || ME.role != 'admin') return admin();
  const c = (await api('/api/admin/empresas')).find(x => x.id == id);
  if (!c) return `<div class="pg">Empresa não encontrada.</div>`;
  const portes = ['1 a 50', '51 a 200', '201 a 1.000', '1.001 a 5.000', '+5.000'];
  return `<div class="pg"><a class="more" href="#/admin" onclick="ADM='empresas'">← Voltar ao painel</a><form class="card form" style="margin-top:16px" onsubmit="return salvarEmp(event,'${esc(c.id)}')"><h2>Editar empresa</h2>
  <label>Nome</label><input id="en" required maxlength="80" value="${esc(c.nome)}">
  <div class="row"><div><label>Setor</label><input id="es" required maxlength="60" value="${esc(c.setor)}"></div><div><label>Faixa de funcionários</label><select id="ep">${portes.map(p => `<option ${p == c.porte ? 'selected' : ''}>${p}</option>`).join('')}</select></div></div>
  <div class="row"><div><label>Sede</label><input id="ed" required maxlength="80" value="${esc(c.sede)}"></div><div><label>Selo / destaque</label><input id="et" required maxlength="60" value="${esc(c.tag)}"></div></div>
  <label>Descrição</label><textarea id="ex" rows="4" maxlength="500">${esc(c.desc)}</textarea>
  <label>Status</label><select id="est"><option value="aprovada" ${c.status == 'aprovada' ? 'selected' : ''}>Aprovada (visível para todos)</option><option value="pendente" ${c.status == 'pendente' ? 'selected' : ''}>Pendente (oculta)</option></select><br><br><button class="btn" style="width:100%">Salvar alterações</button></form></div>`
}
async function salvarEmp(e, id) {
  e.preventDefault();
  try { await api('/api/admin/empresas/' + encodeURIComponent(id), { method: 'PATCH', body: { nome: $('#en').value, setor: $('#es').value, porte: $('#ep').value, sede: $('#ed').value, tag: $('#et').value, desc: $('#ex').value, status: $('#est').value } }); toast('Empresa atualizada.'); ADM = 'empresas'; location.hash = '#/admin' } catch (err) { toast(err.message) }
  return false
}
async function admAvaliacoes() {
  const rs = await api('/api/admin/avaliacoes' + (ADMF != 'todos' ? '?status=' + ADMF : ''));
  const filtro = `<div style="margin-bottom:14px;max-width:260px"><select onchange="ADMF=this.value;route(true)"><option value="todos">Todas as avaliações</option><option value="pendente" ${ADMF == 'pendente' ? 'selected' : ''}>Só pendentes</option><option value="aprovada" ${ADMF == 'aprovada' ? 'selected' : ''}>Só aprovadas</option></select></div>`;
  if (!rs.length) return filtro + vazio('Nenhuma avaliação encontrada.');
  return filtro + tabela(['Empresa', 'Avaliação', 'Autor', 'Status', 'Ações'], rs.map(r => `<tr><td><a class="more" href="#/empresa/${esc(r.empresa_id)}">${esc(r.empresa)}</a><div class="mut">${fmtData(r.criado_em)}</div></td>
  <td style="min-width:280px"><b>${esc(r.titulo)}</b> ${stars(r.media)}<div class="mut" style="white-space:pre-line">${esc(r.texto.length > 220 ? r.texto.slice(0, 220) + '…' : r.texto)}</div></td>
  <td>${esc(r.nome)} · ${esc(r.cargo)}<div class="mut">${r.autor_email ? esc(r.autor_email) : 'Dados iniciais'}</div></td><td>${bStatus(r.status)}</td>
  <td><div class="acts">${r.status == 'pendente' ? `<button class="btn sm" onclick="adm('/api/admin/avaliacoes/${r.id}','PATCH',{status:'aprovada'},'Avaliação aprovada.')">Aprovar</button>` : `<button class="btn sm o" onclick="adm('/api/admin/avaliacoes/${r.id}','PATCH',{status:'pendente'},'Avaliação ocultada.')">Ocultar</button>`}
  <button class="btn sm o" onclick="adm('/api/admin/avaliacoes/${r.id}','DELETE',null,'Avaliação excluída.','Excluir esta avaliação definitivamente?')">Excluir</button></div></td></tr>`))
}
async function admUsuarios() {
  const us = await api('/api/admin/usuarios');
  return tabela(['Usuário', 'Perfil', 'Situação', 'Avaliações', 'Entrou em', 'Ações'], us.map(u => {
    const eu = u.id == ME.id;
    return `<tr><td>${esc(u.nome)}<div class="mut">${esc(u.email)}</div></td><td>${u.role == 'admin' ? '<span class="badge adm">Administrador</span>' : '<span class="badge">Usuário</span>'}</td><td>${u.bloqueado ? '<span class="badge pend">Bloqueado</span>' : '<span class="badge ok">Ativo</span>'}</td><td>${u.avaliacoes}</td><td>${fmtData(u.criado_em)}</td>
    <td>${eu ? '<span class="mut">Você</span>' : `<div class="acts"><button class="btn sm o" onclick="adm('/api/admin/usuarios/${u.id}','PATCH',{role:'${u.role == 'admin' ? 'user' : 'admin'}'},'Perfil atualizado.','${u.role == 'admin' ? 'Remover os poderes de administrador deste usuário?' : 'Tornar este usuário administrador? Ele terá acesso total ao painel.'}')">${u.role == 'admin' ? 'Tirar admin' : 'Tornar admin'}</button>
    <button class="btn sm o" onclick="adm('/api/admin/usuarios/${u.id}','PATCH',{bloqueado:${u.bloqueado ? 'false' : 'true'}},'${u.bloqueado ? 'Usuário desbloqueado.' : 'Usuário bloqueado.'}')">${u.bloqueado ? 'Desbloquear' : 'Bloquear'}</button>
    <button class="btn sm o" onclick="adm('/api/admin/usuarios/${u.id}','DELETE',null,'Usuário excluído.','Excluir esta conta? As avaliações dela continuam publicadas, sem vínculo com a conta.')">Excluir</button></div>`}</td></tr>`
  }))
}
async function admContatos() {
  const cs = await api('/api/admin/contatos');
  if (!cs.length) return vazio('Nenhum contato B2B recebido ainda.');
  return tabela(['Empresa', 'E-mail', 'Plano', 'Data', ''], cs.map(c => `<tr><td>${esc(c.empresa)}</td><td><a class="more" href="mailto:${esc(c.email)}">${esc(c.email)}</a></td><td>${esc(c.plano)}</td><td>${fmtData(c.criado_em)}</td><td><button class="btn sm o" onclick="adm('/api/admin/contatos/${c.id}','DELETE',null,'Contato removido.','Remover este contato da lista?')">Remover</button></td></tr>`))
}

async function admMensagens() {
  const ms = await api('/api/admin/mensagens');
  if (!ms.length) return vazio('Nenhuma mensagem recebida ainda.');
  return tabela(['De', 'Assunto', 'Mensagem', 'Data', 'Ações'], ms.map(m => `<tr><td>${esc(m.nome)}<div class="mut">${esc(m.email)}</div>${m.lida ? '' : '<span class="badge pend">Nova</span>'}</td><td>${esc(m.assunto)}</td><td style="min-width:280px;white-space:pre-line">${esc(m.mensagem)}</td><td>${fmtData(m.criado_em)}</td>
  <td><div class="acts"><a class="btn sm" href="mailto:${esc(m.email)}?subject=${encodeURIComponent('Re: ' + m.assunto + ' - FeedWork')}">Responder</a><button class="btn sm o" onclick="adm('/api/admin/mensagens/${m.id}','PATCH',{lida:${!m.lida}},'${m.lida ? 'Marcada como não lida.' : 'Marcada como lida.'}')">${m.lida ? 'Marcar não lida' : 'Marcar lida'}</button><button class="btn sm o" onclick="adm('/api/admin/mensagens/${m.id}','DELETE',null,'Mensagem excluída.','Excluir esta mensagem?')">Excluir</button></div></td></tr>`))
}
async function admPalavras() {
  const ps = await api('/api/admin/palavras');
  return `<div class="card" style="margin-bottom:16px"><h3>Filtro de palavras</h3><p class="mut" style="margin:6px 0 12px">Textos com estas palavras são recusados no cadastro de conta, no cadastro de empresa e nas avaliações. Basta cadastrar a palavra <b>uma vez</b>: o filtro reconhece sozinho maiúsculas, acentos, letras repetidas (<i>puuuta</i>), números e símbolos no lugar de letras (<i>p0rra</i>, <i>m3rd@</i>), letras separadas (<i>p u t a</i>, <i>p.u.t.a</i>) e letras escondidas por símbolo (<i>p*ta</i>). Vale para a palavra inteira, então "computador" não é barrado por "puta". Para pegar também as derivadas, termine com <b>*</b> (ex.: <b>idiot*</b> bloqueia idiota, idiotice...). Administradores não são filtrados.</p>
  <form onsubmit="return addPalavras(event)"><textarea id="pw" rows="3" required placeholder="Digite uma ou mais palavras, separadas por vírgula ou uma por linha"></textarea><br><br><button class="btn sm">Adicionar ao filtro</button></form></div>
  <div class="card"><b>${ps.length} palavra(s) bloqueada(s)</b> <span class="mut">(clique para remover)</span><div class="catbar" style="margin-top:12px">${ps.length ? ps.map(p => `<button title="Remover do filtro" onclick="adm('/api/admin/palavras/${p.id}','DELETE',null,'Palavra removida do filtro.')">${esc(p.palavra)} ✕</button>`).join('') : '<span class="mut">Nenhuma palavra cadastrada.</span>'}</div></div>`
}
async function addPalavras(e) {
  e.preventDefault();
  try { const r = await api('/api/admin/palavras', { body: { palavras: $('#pw').value } }); toast(r.adicionadas ? r.adicionadas + ' palavra(s) adicionada(s) ao filtro.' : 'Essas palavras já estavam no filtro.'); route(true) } catch (err) { toast(err.message) }
  return false
}

/* ===== Rotas ===== */
async function route(manter) {
  const [, p, id] = location.hash.slice(1).split('/');
  const eu = ++RT, y = window.scrollY;
  let html;
  try {
    const pag = { '': home, empresas, empresa: () => empresa(id), avaliar: () => avaliar(id), 'nova-empresa': novaEmpresa, b2b, contato, entrar, admin, 'admin-empresa': () => admEditar(id) }[p || ''] || home;
    html = await pag();
  } catch (e) {
    html = `<div class="pg"><div class="card form"><h2>Ops!</h2><p class="mut">${esc(e.message || 'Não foi possível carregar esta página.')}</p><br><a class="btn" href="#/">Voltar ao início</a></div></div>`;
  }
  if (eu != RT) return;   // outra navegação começou enquanto esta carregava
  $('#app').innerHTML = html;
  window.scrollTo(0, manter === true ? y : 0)
}
addEventListener('hashchange', () => { TAB = NEXTTAB || 'geral'; NEXTTAB = null; route() });
(async () => { try { ME = (await api('/api/auth/eu')).user } catch (e) { } setLogin(); route() })();
